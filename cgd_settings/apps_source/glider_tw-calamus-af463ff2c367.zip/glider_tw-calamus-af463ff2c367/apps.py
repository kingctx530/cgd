from django.apps import AppConfig


class CalamusConfig(AppConfig):
    name = 'calamus'
